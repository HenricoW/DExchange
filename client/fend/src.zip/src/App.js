import React from "react";
import Footer from './Footer.js';

function App() {
  return (
    <div id="app">
     <div>
       Header
      </div>
      <div>
        Main part
      </div>
      <Footer />
    </div>
  );
}

export default App;
